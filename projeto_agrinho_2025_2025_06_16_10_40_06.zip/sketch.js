let jardineiro;
let plantas = [];
let totalVerdes = 0;
let totalPoluidas = 0;

function setup() {
  createCanvas(600, 400);
  jardineiro = new Jardineiro(width / 2, height - 70);
}

function draw() {
  // Calcula proporção entre árvores boas e ruins
  let total = totalVerdes + totalPoluidas;
  let proporcaoVerde = total > 0 ? totalVerdes / total : 0.2;

  // Cor de fundo baseada no equilíbrio ambiental
  let corFundo = lerpColor(color(255, 0, 0), color(0, 100, 255), proporcaoVerde);
  background(corFundo);

  mostrarInformacoes();

  jardineiro.atualizar();
  jardineiro.mostrar();

  for (let arvore of plantas) {
    arvore.mostrar();
  }
}

function mostrarInformacoes() {
  textSize(16);
  fill(0);
  text("Árvores verdes: " + totalVerdes, 20, 30);
  text("Árvores poluídas: " + totalPoluidas, 20, 50);
  text("Total: " + (totalVerdes + totalPoluidas), 20, 70);
}

class Jardineiro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  atualizar() {
    this.x = mouseX;
    this.y = mouseY;
  }

  mostrar() {
    fill(100, 200, 100);
    ellipse(this.x, this.y, 30, 30);
  }
}

class Arvore {
  constructor(x, y, poluida = false) {
    this.x = x;
    this.y = y;
    this.poluida = poluida;
  }

  mostrar() {
    // Tronco
    fill(101, 67, 33);
    rect(this.x - 5, this.y + 20, 10, 25);

    // Copa
    if (this.poluida) {
      fill(30);
    } else {
      fill(34, 139, 34);
    }

    noStroke();
    ellipse(this.x, this.y, 30, 30);
    ellipse(this.x - 10, this.y + 5, 25, 25);
    ellipse(this.x + 10, this.y + 5, 25, 25);
    ellipse(this.x, this.y + 10, 25, 25);
  }
}

function mousePressed() {
  let chancePoluida = random() < 0.7;

  plantas.push(new Arvore(jardineiro.x, jardineiro.y, chancePoluida));

  if (chancePoluida) {
    totalPoluidas++;
  } else {
    totalVerdes++;
  }
}


